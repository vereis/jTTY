# jterm
Relatively functional javascript terminal
